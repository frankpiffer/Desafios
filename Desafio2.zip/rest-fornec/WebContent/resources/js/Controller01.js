   var app = angular.module('app',[]);
  
   app.controller('Controller01',['$scope','$http',function($scope,$http) {

       $scope.cadastrarFornecedor = function() {
		   if (validaCampos()){
			
				$http.post('/rest-fornec/rest/fornec/add', $scope.fornec)
				.then(function(response) {
					
							alert("Cadastro efetuado com sucesso!");
							$scope.fornec = limparFornec();
						
					},function(error) {
							alert("Falha no cadastro!!");
					});
				{
                 /**   alert("Cadastro não preenchido!"); */
                     return true;
				}
			}
	 
	};
	
       $scope.pesquisaFornecedor = function() {
		   var busca = userMenu.cm_busca.value
           
		  if (busca == '')
		  {
		    alert("Informe código fornecedor!");
		   
		    return false;
		   }    
			
			$http.get('/rest-fornec/rest/fornec/get/' + busca , $scope.fornec)
				.then(function(response) {
				  $scope.fornec = response.data;	
		  
					
					alert("Busca efetuado com sucesso!");
						
						
					},function(error) {
							alert("Falha na busca!!");
					});
			
			}
 

       $scope.modificarFornecedor = function() {
		   var busca = userMenu.cm_busca.value
		   var lmodifica01 = userform.cm_nome.value
		   var lmodifica02 = userform.id_fornec.value 
		  if (busca == '')
		  {
		    alert("Informe código fornecedor na pesquisa!");
		   
		    return false;
		   }
		   
		  if (lmodifica01 == '')
		  {
		    alert("Informe código fornecedor válido na pesquisa!");
		   
		    return false;
		   }
	
	      if (lmodifica02 == '')
		  {
		    alert("Informe código fornecedor válido na pesquisa!");
		   
		    return false;
		   }
		   		   
			
			$http.put('/rest-fornec/rest/fornec/edit/' + busca , $scope.fornec)
				.then(function(response) {
				  $scope.fornec = response.data;	
				 
					alert("Alteração efetuado com sucesso!");
						
						
					},function(error) {
							alert("Falha na alteração!!");
					});
			
			}

      $scope.excluirFornecedor = function() {
		   var busca = userMenu.cm_busca.value
		   var lmodifica02 = userform.id_fornec.value 
		  if (busca == '')
		  {
		    alert("Informe código fornecedor na pesquisa!");
		   
		    return false;
		   }
	
	      if (lmodifica02 == '')
		  {
		    alert("Informe código fornecedor válido na pesquisa!");
		   
		    return false;
		   }
		   		   
			
			$http.delete('/rest-fornec/rest/fornec/delete/' + lmodifica02 , $scope.fornec)
				.then(function(response) {
				  $scope.fornec = response.data;	
				 
					alert("Exclusão efetuado com sucesso!");
						
						
					},function(error) {
							alert("Falha na exclusão!!");
					});
			
 			}

}])


  function validaCampos() {
 
	 if (userform.cm_nome.value == '')
		{
		alert("Campos obrigatórios faltando!");
		   
		return false;
		} 
		if ( userform.cm_email.value == "")
		{
		alert("Campos obrigatórios faltando!");
		   
		return false;
		}

		if ( userform.cm_cnpj.value == "")
		{
		alert("Campos obrigatórios faltando!");
		    
		return false;
		}
		return true; 
  }


  function limparFornec() {
	    return {
			   id_fornec : "",
			   cm_nome : "",
			   cm_email : "",
			   cm_coment : "",
			   cm_cnpj   : ""
                   
		}
	   
   }



