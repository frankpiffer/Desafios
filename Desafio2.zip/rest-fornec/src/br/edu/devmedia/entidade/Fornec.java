package br.edu.devmedia.entidade;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Fornec {

	private int id_fornec;

	private String cm_nome;

	private String cm_email;
	
	private String cm_coment;

	private String cm_cnpj;	
		

	public int getId_fornec() {
		return id_fornec;
	}	
	
	public void setId_fornec(int id_fornec) {
		this.id_fornec = id_fornec;
	}

	public String getCm_nome() {
		return cm_nome;
	}

	public void setCm_nome(String cm_nome) {
		this.cm_nome = cm_nome;
	}

	public String getCm_email() {
		return cm_email;
	}

	public void setCm_email(String cm_email) {
		this.cm_email = cm_email;
	}

	public String getCm_coment() {
		return cm_coment;
	}

	public void setCm_coment(String cm_coment) {
		this.cm_coment = cm_coment;
	}	

	public String getCm_cnpj() {
		return cm_cnpj;
	}

	public void setCm_cnpj(String cm_cnpj) {
		this.cm_cnpj = cm_cnpj;
	}	
		
	
	
	
	
}
