package br.edu.devmedia.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import br.edu.devmedia.config.BDConfig;
import br.edu.devmedia.entidade.Fornec;

public class FornecDAO {
	
	public List<Fornec> listarFornecs() throws Exception {
		List<Fornec> lista = new ArrayList<>();

		Connection conexao = BDConfig.getConnection();

		String sql = "SELECT * FROM tb_fornec";

		PreparedStatement statement = conexao.prepareStatement(sql);
		ResultSet rs = statement.executeQuery();

		while (rs.next()) {
			Fornec fornec = new Fornec();
			fornec.setId_fornec(rs.getInt("ID_FORNEC"));
			fornec.setCm_nome(rs.getString("CM_NOME"));
			fornec.setCm_email(rs.getString("CM_EMAIL"));
			fornec.setCm_coment(rs.getString("CM_COMENT"));
			fornec.setCm_cnpj(rs.getString("CM_CNPJ"));
			
			lista.add(fornec);
		}

		return lista;
	}
	
	public Fornec buscarFornecPorId(int idFornec) throws Exception {
		Fornec fornec = null;

		Connection conexao = BDConfig.getConnection();

		String sql = "SELECT * FROM tb_fornec WHERE id_fornec = ?";
		System.out.println(sql);
		PreparedStatement statement = conexao.prepareStatement(sql);
		statement.setInt(1, idFornec);
		ResultSet rs = statement.executeQuery();

		if (rs.next()) {
			fornec = new Fornec();
			fornec.setId_fornec(rs.getInt("ID_FORNEC"));
			fornec.setCm_nome(rs.getString("CM_NOME"));
			fornec.setCm_email(rs.getString("CM_EMAIL"));
			fornec.setCm_coment(rs.getString("CM_COMENT"));
			fornec.setCm_cnpj(rs.getString("CM_CNPJ"));
					
		}
        
		return fornec;
	}

	public int addFornec(Fornec fornec) throws Exception {
		int idGerado = 0;
		Connection conexao = BDConfig.getConnection();

		String sql = "INSERT INTO tb_fornec(CM_NOME,CM_EMAIL,CM_COMENT,CM_CNPJ) VALUES(?,?,?,?)";

		PreparedStatement statement = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
		statement.setString(1, fornec.getCm_nome());
		statement.setString(2, fornec.getCm_email());
		statement.setString(3, fornec.getCm_coment());
		statement.setString(4, fornec.getCm_cnpj());
		statement.execute();
		
		ResultSet rs = statement.getGeneratedKeys();
		if (rs.next()) {
			idGerado = rs.getInt(1);
		}
		
		return idGerado;
	}
	
	public void editarFornec(Fornec fornec, int idFornec) throws Exception {
		Connection conexao = BDConfig.getConnection();

	String sql = "UPDATE tb_fornec SET cm_nome = ?, cm_email = ? , cm_coment = ?, cm_cnpj = ? WHERE id_fornec = ?";

		PreparedStatement statement = conexao.prepareStatement(sql);
		statement.setString(1, fornec.getCm_nome());
		statement.setString(2, fornec.getCm_email());
		
		statement.setString(3, fornec.getCm_coment());
		statement.setString(4, fornec.getCm_cnpj());
				
		statement.setInt(5, idFornec);
		statement.execute();
	}
	
	public void removerFornec(int idFornec) throws Exception {
		Connection conexao = BDConfig.getConnection();

		String sql = "DELETE FROM tb_fornec WHERE id_fornec = ?";

		PreparedStatement statement = conexao.prepareStatement(sql);
		statement.setInt(1, idFornec);
		statement.execute();
	}
	
}
